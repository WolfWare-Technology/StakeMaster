===============================================================================
 __      __       __   _____  __      __
/  \    /  \____ |  |_/ ____\/  \    /  \_____ _______   ____   
\   \/\/   /  _ \|  |\   __\ \   \/\/   /\__  \\_  __ \_/ __ \   
 \        (  <_> )  |_|  |    \        /  / __ \|  | \/\  ___/   
  \__/\  / \____/|____/__|     \__/\  /  (____  /__|    \___  >  
       \/                           \/        \/            \/         
___________            __                   __                       
\__    ___/___   ____ |  |__   ____   ____ |  |   ____   ____ ___ __
  |    |_/ __ \_/ ___\|  |  \ /    \ /  _ \|  |  /  _ \ / ___<   |  |
  |    |\  ___/\  \___|   Y  \   |  (  <_> )  |_(  <_> ) /_/  >___  |
  |____| \___  >\___  >___|  /___|  /\____/|____/\____/\___  // ____|
             \/     \/     \/     \/                  /_____/ \/     
===============================================================================

Autor:   [WolfWare Technology]
Website: [https://WolfWare.Site]
Discord: [https://discord.gg/t44Yqbgpcu]


=================================================================================
IMPORTANT NOTICE
=================================================================================

By using this betting bot, you acknowledge that you are engaging in real-money
betting, which is a form of gambling. Please be aware that, over the long term,
you are very likely to loose. More information at https://www.begambleaware.org

WolfWare Technology is not responsible for any financial losses incurred as a
result of strategies you create or through the use of this bot. By proceeding
with the use of this software, you confirm your understanding and acceptance
of these terms, and you release WolfWare Technology from any liability related
to your gambling activities.

Furthermore by applying your cookie credentials you understand that this is 
sensitive information of your Stake-Account. This data will only be stored in
the local config file of the software found under:
/Appdata/Local/WolfWare-Technology/Stake-Master.../[version]/user.config

These Cookies settings allow the bot to perform bets so every person with this
data would be able to perform requests using your credentials so please keep
them secret and don't use the software if you think this would be a harm for you.

If you have any questions regarding the security of your data or any functions
of the Software feel free to visit our Discord mentioned above for help.

=================================================================================
Description
=================================================================================

The StakeMaster is all you need when it comes to efficiently managing your
gambling strategies. With a variety of supported Games, this software is a
must-have for both individual players and professional betting experts.

Crafted with a user-friendly interface, the StakeMaster offers seamless access
to your Stake Account without any API, enabling users to secure their own Data.
Whether you're a casual player trying out some new Ides or an expertised
professional aiming for optimization on both, betting-speed and effiency, this
software serves as your ultimate companion.

Elevate your betting experience today with our StakeMaster Beta and unlock the
full potential of your gaming journey.


Feel free to visit our Discord for Questions and Support.
We also offer an individual customization for all of our products to guarantee
Customer-Satisfaction in every regard

=================================================================================
Setup
=================================================================================

- Open StakeMaster.exe
- Enter your Website-Username with a password and register
- Log into your Account
- Open your Browser and navigate to a Stake Originals Game (such as Dice)
- Right-Click on an empty spot on the screen and hit "Inspect"
- Navigate to the "Network" Tab and place a Bet on Stake (dno bet amount required)
- Right-Click the "graphql" request and hit "Copy"→ "copy as cURL (bash)"
- Insert copied Text into the "Detect automatically" Textfield in the
  StakeMaster.exe and click "Check"
- Enjoy the StakeMaster Beta by WolfWare Technology

- Note: When you don't see a "graphql" request in your Inspection-Tab you might
	need to change your browser as Opera for example does not show it

=================================================================================
Supported Games and Features
=================================================================================

The StakeMaster is currently in Beta so the Supported Games will be updated

- Diamonds
- Dice
- Mines
- Limbo

Every Game has their own basic features, followed by advanced betting options
for Premium-Users. Navigate throught the Tabs to view the available Strategies.

=================================================================================
Changelog
=================================================================================

[Version 1.1.0.3] - 2024-08-13 [BETA RELEASE]
----------------------------

### Added
- Implementation of Games: Diamonds, Dice, Mines, Limbo
- Implementation of automatic extraction of cookies using cURL command
- Implementation of various basic and advanced Betting-Strategies
- Visualization and UI-Build
- Implementation of simple Statistics and Advanced-Tab
- Statistics
- Import/Export of Tables

### Changed
- Errors of too many requests are ignored now so autoplay won't stop

### Resolved
- Logging in Issues
- Program Closing when accepting the Important Notice
- Login/Register Issues were resolved

### Deleted
- 

### Coming soon
- Games: Hilo, Dragon Tower

### Known Issues/Bugs
- No Bugs reported. - View Https://WolfWare.Site/Status to report bugs